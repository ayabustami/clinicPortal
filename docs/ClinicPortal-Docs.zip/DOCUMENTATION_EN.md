# 📖 Clinic Portal — Documentation

A complete, clear guide to using and running the platform. This document mirrors the Arabic guide ([DOCUMENTATION_AR.md](DOCUMENTATION_AR.md)).

---

## 📑 Table of Contents

1. [What is the Platform?](#1-what-is-the-platform)
2. [Main Features](#2-main-features)
3. [Running the Project (Developers)](#3-running-the-project-developers)
4. [Login & Account](#4-login--account)
5. [Roles & Permissions](#5-roles--permissions)
6. [Pages Guide](#6-pages-guide)
7. [Typical Daily Workflow](#7-typical-daily-workflow)
8. [Appointment Status Flow](#8-appointment-status-flow)
9. [Environment & Deployment](#9-environment--deployment)
10. [Security & Privacy](#10-security--privacy)
11. [FAQ & Troubleshooting](#11-faq--troubleshooting)

---

## 1. What is the Platform?

**Clinic Portal** is a complete web system for managing medical and dental clinics. It runs as a single-page application (SPA) backed by a REST API and a PostgreSQL database.

The system enables a clinic to:

- 📅 Book and manage appointments (calendar + list)
- 👥 Register patients and manage their files
- 🩺 Document clinical records and prescriptions
- 🦷 Use an interactive dental chart (Odontogram)
- 💰 Issue invoices and record payments
- 📊 View operational and financial reports
- 🔒 Enforce role-based permissions with a full audit trail

> **Note:** The system is **multi-tenant** — every clinic's data is fully isolated. No user can see another clinic's data.

### Tech Stack

| Layer | Technology |
|-------|------------|
| Frontend | React 18 + Vite 5 (JavaScript) |
| Calendar | FullCalendar 6 with timezone support |
| Backend | Node.js ≥ 20 + Express 4 (REST JSON API) |
| Database | PostgreSQL 14+ (Neon-compatible) |
| Authentication | JWT in a secure httpOnly cookie + bcrypt |
| Languages | English + Arabic (full RTL) |

---

## 2. Main Features

### 📅 Appointments
- Calendar views: Month / Week / Day / Agenda
- Drag-and-drop to reschedule or resize appointments (with confirmation before saving)
- Search by name or phone number + filters (doctor, branch, status)
- Server-side prevention of double-booking
- Doctor leave blocks render as striped areas — the server rejects bookings inside them

### 🩺 Clinical Records
- Lifecycle: **draft → approved**
- Approved records are **locked** — any change requires a new record
- Prescriptions are updated as **diffs** with a full audit trail (add/remove/edit)
- File attachments (PDF/images up to 10 MB) with real file-type validation

### 🦷 Dental Chart (Odontogram)
- Interactive visual chart (SVG) with FDI numbering
- Colors, patterns, and letter badges for conditions (never color alone)
- Three separate layers: current findings 🟢 / planned treatments 🔵 / completed procedures ✅
- Append-only history (`dental_history`) — nothing is ever overwritten silently

### 💰 Invoicing
- Automatic sequential numbering `INV-2026-0001`
- Invoices linked to appointments and patients (with server-side validation)
- Fully paid invoices are **automatically locked**
- Configurable currency via Settings (ILS default — JOD, USD, EUR…)

### 📊 Reports
- Appointments / Revenue / New patients / Operations
- No-show rate per doctor, utilization vs capacity, revenue by service, receivables aging 30/60/90
- Excel-safe CSV export (Arabic-friendly: UTF-8 BOM + formula-injection protection)

---

## 3. Running the Project (Developers)

### Requirements
- **Node.js ≥ 20** and npm
- **PostgreSQL 14+** (cloud, e.g. Neon, or local)

### Steps

```bash
# 1. Install dependencies
npm run setup

# 2. Configure the environment
cp server/.env.example server/.env
# then set DATABASE_URL and JWT_SECRET inside the file

# 3. Prepare the database
cd server
npm run db:check     # verify database connectivity
npm run migrate      # apply migrations
npm run seed         # load demo data (refused in production)

# 4. Run (in two separate terminals)
npm run dev:server   # API on http://localhost:4000
npm run dev:client   # SPA on http://localhost:5173
```

Open **http://localhost:5173** — you can switch languages (English / العربية) from the top bar or the login screen.

### Demo Accounts

All demo accounts use the password: **`Demo1234!`**

| Role | Email |
|------|-------|
| Clinic Owner | `owner@alamal.demo` |
| Receptionist | `reception@alamal.demo` |
| Doctor | `lina@alamal.demo` |
| Accountant | `accounting@alamal.demo` |
| Platform Admin | `admin@clinicportal.local` |

> Running `npm run seed` creates two demo clinics (Al Amal Family Clinic and Cedar Heights Clinic) for exploration and testing.

---

## 4. Login & Account

### Signing In
1. Open the login page (`/login`).
2. Enter your **email** and **password**.
3. Click **Sign In**.

> 🔒 For security, the system shows one generic error ("Invalid credentials") whether the email doesn't exist or the password is wrong.

### Forgot Password?
1. From the login screen click **Forgot password?**.
2. Enter your email — you'll receive a **6-digit verification code** (valid for 15 minutes).
3. Enter the code, then set a new password.

> In development without an email provider, the code is echoed in the API response so the flow can be completed.

### Changing Your Password (from inside the app)
1. Go to **My Account** from the sidebar.
2. Click **Change Password**.
3. Enter your current password + the code sent to your email + the new password.

> Changing your password immediately revokes all sessions on other devices.

### Email Verification Codes
Single-use codes are used in three cases:
- Forgot-password recovery
- Password-change confirmation
- Staff account-setup invitations

Codes are stored hashed (SHA-256), expire after 15 minutes, and allow at most 5 verification attempts.

---

## 5. Roles & Permissions

There are **5 roles**, and each role's permissions are enforced **by the server** (not just the UI):

| Permission | Clinic Owner (owner) | Receptionist | Doctor | Accountant | Platform Admin |
|---|:---:|:---:|:---:|:---:|:---:|
| Dashboard | ✅ | ✅ | ✅ | ✅ | — |
| Appointments (create/edit/status) | ✅ | ✅ | ✅ (own only) | ❌ | — |
| Waiting Room | ✅ | ✅ | ✅ | ❌ | — |
| Patient registration | ✅ | ✅ | ❌ | ❌ | — |
| Clinical records (read/write) | ✅ | read-only | ✅ | ❌ | — |
| Dental chart | ✅ | ❌ | ✅ | ❌ | — |
| Create invoices | ✅ | ❌ | ✅ | ✅ | — |
| Payments & revenue | ✅ | ❌ | ❌ | ✅ | — |
| Reports | ✅ | ✅ (appointments) | ❌ | ✅ | — |
| Staff management | ✅ | ❌ | ❌ | ❌ | — |
| Clinic settings | ✅ | ❌ | ❌ | ❌ | — |
| Audit trail | ✅ | ❌ | ❌ | ❌ | — |
| Platform clinics management | ❌ | ❌ | ❌ | ❌ | ✅ |

### Important Rules
- A **doctor** only sees and manages **their own** appointments.
- The **last active owner** of a clinic can never be demoted or deactivated (server-enforced).
- The **Platform Admin** manages clinics and owners only — no access to clinical data.
- Deactivating a staff member revokes all their live sessions immediately.

---

## 6. Pages Guide

### 🏠 Dashboard — `/`
- Greeting + today's summary: appointments count, active patients, doctors, and (for financial roles) revenue.
- **Quick cards**: Waiting room (checked in) and "In treatment" and today's schedule.
- Click any card to jump straight to the page.

### 📅 Appointments — `/appointments`
One page containing the **calendar** and the **list** with the same data and filters.

| Element | Function |
|---------|----------|
| **+ New Appointment** button | Opens the booking form (works even without a selected slot) |
| Search | By name or phone (Arabic-insensitive: hamza/diacritics normalized) |
| Filters | Doctor / Branch / Status |
| Navigation | Today ← Prev / Next + date jump |
| Views | Month / Week / Day / Agenda (mobile: Day + Agenda) |

**Advanced:**
- Drag an event to change its time, or resize its edges to change duration — with a **confirmation before saving**; the server rejects invalid slots and the event reverts.
- Each event carries the **doctor's color** (side stripe in time grids, dot in month view).
- Doctor leave blocks render as striped areas; the server refuses bookings inside them.
- Role-aware today summary chips (total, checked-in, completed, cancelled).

### 🪑 Waiting Room — `/waiting-room`
> Available to: Clinic Owner, Receptionist, Doctor.

- Shows patients who have **checked in** and are waiting.
- Add a patient to the room directly.
- Move on to starting the visit or opening the visit workspace.

### 🩺 My Day — `/my-day`
> Doctors only.

- Today's appointment queue for the signed-in doctor.
- Quick action buttons: **Check in** → **Start visit** → **Add clinical note** → **Complete & invoice**.

### 🧭 Visit Workspace — `/visits/:id`
A unified workspace for every visit:
1. **Patient alerts** (allergies, medical info) at the top.
2. **Services** requested in this appointment with prices.
3. **Visit progress** (current status + actions).
4. Buttons: open a pre-filled new clinical record, complete the visit and create the invoice.

### 👥 Patients — `/patients`
- Patient list with Arabic-insensitive search (hamza, diacritics, ta-marbuta).
- Register a new patient (Owner + Receptionist only).
- **Patient profile** `/patients/:id` includes:
  - Basic info and medical fields (visible to clinical + front-desk roles only)
  - **Timeline**: all patient events (appointments, records, invoices), filtered by your role
  - **Dental Chart** tab (doctors & owners): interactive per-tooth chart
  - Deactivate/reactivate the patient while keeping the full history

### 🦷 Dental Chart — `/patients/:id/dental`
- FDI numbering (permanent 11–48, primary 51–85).
- Colors, patterns, and letter badges for conditions (never color alone).
- Three separate layers: current findings 🟢 / planned treatments 🔵 / completed procedures ✅.
- Every edit/correction is recorded in `dental_history` + the audit log (with a required reason).
- Contradictory states (e.g. caries on a missing tooth) are rejected for clinician review.

### 📄 Records — `/records`
> Available to: Clinic Owner, Doctor, Receptionist.

- Clinical records with a **draft → approved** lifecycle:
  - Draft: editable by its author (the treating doctor or the owner).
  - Approved: **locked** — content edits return 409; corrections require a new record.
- Prescriptions are updated as **diffs**, fully audited (before/after).
- Attachments (PDF/JPEG/PNG/WEBP up to 10 MB) with MIME **and magic-byte** validation.

### 💰 Invoices — `/invoices` and `/invoices/:id`
> Available to: Clinic Owner, Accountant, Doctor.

- Invoice list + create a new invoice (auto number `INV-year-####`).
- Link the invoice to an appointment (the system validates: same clinic, same patient).
- **Record payments** (multiple partial payments allowed).
- A **fully paid invoice is locked**: no item edits, no overpayment (rejected by the server).
- A currency snapshot is stored with each invoice (immune to later clinic-currency changes).

### 📊 Reports — `/reports`
> Available to: Clinic Owner, Accountant, Receptionist (per tab).

| Tab | Content |
|-----|---------|
| Appointments | Appointments summary + breakdown by doctor |
| Revenue | Revenue + collections by payment method (financial roles only) |
| Operations | No-show rate, utilization, revenue by service, receivables aging (financial roles only) |
| New patients | New patients in the selected range (with pagination) |

- Every report supports **CSV export**, Excel-safe and Arabic-friendly (BOM + formula-injection neutralization).

### 👨‍⚕️ Staff — `/staff`
> Clinic Owner only.

- Manage doctors (name, specialty, color, active flag).
- Manage user accounts (roles) + send **account-setup invitations** by email.

### 🧩 Services — `/services`
> Available to: Clinic Owner, Receptionist.

- Define clinic services: name, duration, price, active flag.
- Used directly in booking and invoicing.

### ⚙️ Clinic Settings — `/settings`
> Clinic Owner only.

| Section | What you can edit |
|---------|-------------------|
| Clinic profile | Clinic name, IANA timezone, default slot length, **currency** |
| Branches / locations | Branches (add / edit / activate / deactivate) |
| Working hours | Per-weekday working hours — enforced server-side by the calendar |

> **Note:** The calendar renders in the **clinic's timezone** (not the browser's), and working-hours rules are validated on the server.

### 🛡️ Audit Trail — `/audit`
> Clinic Owner only.

- An **append-only, un-editable** log of everything: auth, scheduling, clinical, billing, staff, settings, attachments.
- Filters: action / entity / user / date.
- No update/delete endpoints exist for audit rows.

### 👤 My Account — `/account`
- Your personal profile.
- Change password (with an emailed verification code).
- Sign out everywhere (revoke all sessions).

### 🏢 Platform Clinics — `/admin/clinics`
> Platform Admin only.

- Create new clinics and assign an owner to each.
- Manage clinics at the platform level.

---

## 7. Typical Daily Workflow

### From booking to invoice (the full path):

```
① Book an appointment
   Appointments page → "+ New Appointment" → pick patient, doctor, service, time
        ↓
② Confirm the appointment (optional)
   Status: scheduled → confirmed
        ↓
③ Patient arrives → Check in
   From the Waiting Room, My Day, or the appointment itself
   Status: confirmed → checked_in
        ↓
④ Start the visit
   Status: checked_in → in_progress
        ↓
⑤ Clinical work
   Visit Workspace → clinical note (opens pre-filled with the appointment)
   → dental chart if needed → prescription → attachments
        ↓
⑥ Complete & invoice
   Status: in_progress → completed
   → the invoice form opens pre-filled → add items → record payment
```

### Daily tips
- Use the **+ New Appointment** button in the top bar for quick booking from any page.
- Click a patient's name anywhere to open their profile instantly.
- In the calendar: drag an event to change its time — the system asks for confirmation before saving.

---

## 8. Appointment Status Flow

The server enforces this sequence (it cannot be skipped):

```
scheduled → confirmed → checked_in → in_progress → completed
                   ↘ cancelled              ↘ no_show
```

### Status rules (very important):
| Rule | Details |
|------|---------|
| Changing status | Only via the status action (PATCH) — regular appointment edits reject status changes |
| `in_progress` and `completed` | Clinical roles only (owner/doctor) |
| Doctor ownership | Doctors manage their own appointments only |
| Restoring a cancelled appointment | The system re-runs **full conflict validation** |
| Concurrent double-booking | The server guarantees exactly one winner (single atomic transaction) |

---

## 9. Environment & Deployment

### Core environment variables (`server/.env`)

| Variable | Description | Required |
|----------|-------------|:---:|
| `DATABASE_URL` | PostgreSQL connection string (prefer Neon's **pooled** `-pooler` URL) | ✅ |
| `JWT_SECRET` | Token signing secret (≥ 32 chars) — production refuses to boot without it | ✅ |
| `PORT` | Server port (default 4000) | — |
| `NODE_ENV` | `development` or `production` | — |
| `CLIENT_ORIGIN` | Allowed origins (comma-separated) for CSRF/origin defense | — |
| `EMAIL_TRANSPORT` | `console` (development) or `http` (real provider such as Resend) | — |
| `EMAIL_HTTP_URL` / `EMAIL_HTTP_API_KEY` / `EMAIL_FROM` | Email provider settings when using `http` | — |

> ⚠️ **Golden rules:**
> - Never put `DATABASE_URL` in any `VITE_*` variable — the frontend must never see it.
> - Never commit `.env` (it is already in `.gitignore`).
> - `npm run seed` **refuses** to run in production unless `ALLOW_DESTRUCTIVE_SEED=YES` is explicitly set.

### Production deployment (single server)

```bash
cd client && npm run build          # build the frontend
cd ../server && npm ci --omit=dev   # production dependencies only
NODE_ENV=production PORT=4000 \
  JWT_SECRET=<strong-random-secret> \
  DATABASE_URL=<neon-url> \
  node src/index.js
```

In this mode the server serves the built frontend (`client/dist`) together with the API.

### Split hosting (SPA + API on different hosts)

> ⚠️ **Critical:** if the SPA and the API live on different origins, mobile Safari blocks the session cookie — login appears to succeed, then every request returns 401.

**Solution:** serve the API through the SPA's own origin:

| Host | Setting |
|------|---------|
| SPA (static) | Rewrite rule: `/api/*` → `https://<api-host>/api/*` (Rewrite) **before** the `/*` → `/index.html` catch-all |
| SPA (env) | Leave `VITE_API_URL` **unset** (the client then uses relative `/api/...` URLs) |
| API (env) | `NODE_ENV=production`, `CLIENT_ORIGIN=https://<spa-host>`, `JWT_SECRET`, `DATABASE_URL` |

**Quick verification after deploying:**
```bash
curl -si https://<spa-host>/api/meta/bootstrap | head -1        # must return 401
curl -si -X POST https://<spa-host>/api/auth/login \
  -H 'Content-Type: application/json' -d '{"password":"x"}'      # must return 400 naming the missing field
```

### Backups
- **PostgreSQL:** use Neon's built-in backups, or schedule `pg_dump -Fc "$DATABASE_URL" > backup.dump`.
- Migrations run automatically at server boot and never destroy existing data.

---

## 10. Security & Privacy

| Feature | Description |
|---------|-------------|
| 🔐 Passwords | Hashed with bcrypt — never stored in plain text |
| 🎫 Sessions | JWT in a secure httpOnly cookie — 12h lifetime by default |
| 🚫 Session revocation | Password change / staff deactivation / logout revokes all sessions immediately |
| 🛡️ CSRF/Origin | `Sec-Fetch-Site` validation + origin allowlist |
| 🔒 Tenant isolation | Every query is scoped to the user's clinic — foreign IDs return 404 |
| 📝 Audit trail | Append-only — no way to edit or delete audit rows |
| 🚧 Production hardening | The server refuses to boot with a weak secret; all SQL is parameterized (no injection) |
| 📧 Verification codes | SHA-256 hashed, expire in 15 minutes, 5 attempts max |
| 📎 Attachments | MIME **and magic-byte** validation, generated storage names, per-clinic folders |

---

## 11. FAQ & Troubleshooting

<details>
<summary><b>Q: Login succeeds but every request returns 401?</b></summary>

This is usually third-party cookie blocking in split hosting (see [Split hosting](#split-hosting-spa--api-on-different-hosts)). Make sure the API is rewritten through the SPA's origin and `VITE_API_URL` is unset.
</details>

<details>
<summary><b>Q: Where do I find verification codes during development?</b></summary>

With `EMAIL_TRANSPORT=console`, messages are printed to the server log (terminal). You can also set `EMAIL_DEV_EXPOSE_CODES=YES` (demo only) to echo the code in the API response.
</details>

<details>
<summary><b>Q: Why can't I edit an approved clinical record?</b></summary>

By design — approved records are **locked** to protect the integrity of the medical file. Create a new record instead.
</details>

<details>
<summary><b>Q: Why can't I edit a paid invoice?</b></summary>

Fully paid invoices are **locked** (no item edits, no overpayment). Corrections are made by issuing a new invoice.
</details>

<details>
<summary><b>Q: The calendar shows a different time than my device?</b></summary>

The calendar runs on the **clinic's timezone** (set in Settings), not your device's — this is intentional for appointment accuracy.
</details>

<details>
<summary><b>Q: What does "no_show" mean?</b></summary>

A final status for an appointment the patient didn't attend — it appears in operations reports (no-show rate per doctor).
</details>

<details>
<summary><b>Q: How do I add a new staff member?</b></summary>

Go to **Staff** (Clinic Owner only) → add a user → the system sends an **account-setup invitation** by email with a verification code.
</details>

<details>
<summary><b>Q: Can two clinics see each other's data?</b></summary>

No. The platform is multi-tenant with full database-level isolation — any cross-clinic ID returns 404.
</details>

<details>
<summary><b>Q: The server refuses to start in production?</b></summary>

Check that:
1. `DATABASE_URL` is set and valid.
2. `JWT_SECRET` is strong (≥ 32 chars, not a default value).
3. The frontend is built (`npm run build` in the client folder).
</details>

<details>
<summary><b>Q: Is there a mobile version?</b></summary>

The UI is fully responsive — on mobile the calendar falls back to Day + Agenda views, and the sidebar becomes a drawer.
</details>

---

## 📚 Further Reading

- [`README.md`](../README.md) — full technical documentation (API, database, tests, migrations).
- [`server/.env.example`](../server/.env.example) — every environment variable with explanations.
- [`DOCUMENTATION_AR.md`](DOCUMENTATION_AR.md) — the Arabic version of this guide.

---

> **Last updated:** October 2026 — version 1.0.0
